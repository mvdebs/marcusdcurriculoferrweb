package empresa;

import java.util.Scanner;		// importando funcao teclado

public class Principal {

	public static void main(String[] args) {
				
		System.out.println("Trabalho de atividade Pratica sobre o Cofre internacional");		// Introduzindo a atividade
		System.out.println("Aluno: Marcus Vinicius da Silva Debon RU: 4293438");				// Identificação pessoal
		System.out.println();
		System.out.println("Buenas, tudo Belezinha? Informe qual funcao deseja realizar:");		// Menu principal iniciado
		System.out.println("1 - Adicionar moeda ao cofrinho:");
		System.out.println("2 - Remover moeda do cofrinho:");
		System.out.println("3 - Listar moedas do cofrinho:");
		System.out.println("4 - Converter todas moedas armazenadas para Real:");
		System.out.println("5 - Finalizar:");

		
		int selecao;									// referencial para receber opcao do usuario
		Cofrinho cofrinho = new Cofrinho();				// instanciando novo objeto na classe Cofrinho
		Scanner teclado = new Scanner(System.in);	
		selecao = teclado.nextInt();					// leitura da opcao do usuario
		
		while(selecao!=5) {								// arco que mantem o usuario no menu principal, sendo encerrado ao optar pelo item 5
			int qualmoeda,valor;						// referencias para o segundo menu(qualmoeda) e para o valor a ser depositado
			switch(selecao) {							// casos para adicionar, remover, listar ou converter moedas
			case 1:										// caso para adicionar moeda
				qualmoeda=0;
				while(qualmoeda>3 || qualmoeda<1) {		// arco criado para repetir o menu no caso de valor inteiro fora do especificado
				System.out.println("1 - Dolar");		// menu das moedas(classes)
				System.out.println("2 - Euro");
				System.out.println("3 - Real");
				qualmoeda = teclado.nextInt();			// leitura da opcao do usuario
				if(qualmoeda>3 || qualmoeda<1) {		// Advertindo o usuario para informar apenas valores inteiros de 1 a 3.
					System.out.println("Valor incorreto. Digitar valor inteiro de 1 a 3");
				}
				}
				System.out.println("Qual valor deseja depositar?");		// arguindo acerca do valor a ser depositado
				valor = teclado.nextInt();								// leitura da opcao do usuario
				
				Moeda moeda;
				if (qualmoeda==1){
					moeda = new Dolar(valor); }		// novo objeto instanciado na classe dolar com atribuicao do valor pelo usuario  
				else if (qualmoeda==2) {
					moeda = new Euro(valor); }		// novo objeto instanciado na classe euro com atribuicao do valor pelo usuario
				else {
					moeda = new Real(valor); }		// novo objeto instanciado na classe real com atribuicao do valor pelo usuario
				
				cofrinho.adicionar(moeda);			// incluindo o novo objeto criado no arraylist cofrinho
				break;

			case 2:									// caso para remover moeda
				qualmoeda=0;
				while(qualmoeda>3 || qualmoeda<1) {	// arco criado para repetir o menu no caso de valor inteiro fora do especificado
				System.out.println("1 - Dolar");
				System.out.println("2 - Euro");
				System.out.println("3 - Real");
				qualmoeda = teclado.nextInt();		// leitura da opcao do usuario
				if(qualmoeda>3 || qualmoeda<1) {
					System.out.println("Valor incorreto. Digitar valor inteiro de 1 a 3");
				}
				}
				System.out.println("Qual valor deseja remover?");
				valor = teclado.nextInt();			// leitura da opcao do usuario	
				if (qualmoeda==1){
					moeda = new Dolar(valor); }
				else if (qualmoeda==2) {
					moeda = new Euro(valor); }
				else {
					moeda = new Real(valor); }
				
				cofrinho.remover(moeda);			// removendo moeda conforme informacao inserida
				
				break;
			case 3:									// caso para listar moedas
				cofrinho.listagemMoedas();
				break;
			case 4:									// caso para converter valores das moedas armazenadas para o real
				cofrinho.totalConvertido();				
				break;
			default:
			
				System.out.println("Valor incorreto. Digitar valor inteiro entre 1 a 5");
							}
			System.out.println("1 - Adcionar moeda:");
			System.out.println("2 - Remover moedas:");
			System.out.println("3 - Listar moeda:");
			System.out.println("4 - Converter para Real:");
			System.out.println("5 - Finalizar:");				// informando acerca de valor digitado fora do limite estabelecido 
			selecao = teclado.nextInt();						// leitura da opcao do usuario
		}
		
	}

}



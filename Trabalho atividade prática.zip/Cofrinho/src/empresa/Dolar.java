package empresa;

public class Dolar extends Moeda {  // classe filha da classe Moeda

	public Dolar(double valor) {	// construtor
		super(valor);
	}

	@Override
	void info() {
		System.out.println("Valor em dolar no cofrinho: "+valor);
	}

	@Override
	double converter() {			// metodo converter especifico para conversao de dolar em real
		return valor * 4.79;
	}

	@Override
	public String toString() {		// metodo para determinar como retornar os valores armazenados na classe
		return "Dolar [valor = " + valor + "]";
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}
}

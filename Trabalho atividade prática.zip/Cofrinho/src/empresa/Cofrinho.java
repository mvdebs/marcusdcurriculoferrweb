package empresa;

import java.util.ArrayList;		// importando funcao de listas

public class Cofrinho{
	private ArrayList<Moeda> listaMoedas = new ArrayList<Moeda>();		// instanciando nova lista privada com moedas a serem instanciadas
	
	public void adicionar(Moeda m) {		// funcao adicionar moeda
		listaMoedas.add(m);					// adiciona moeda conforme dados informados
	}
	public void remover(Moeda m) {			// funcao remover moeda
		listaMoedas.remove(m);				// remove moeda conforme dados informados
	}
	public void listagemMoedas() {			// funcao listar moeda
		for(Moeda m : listaMoedas) {
			System.out.println(m);			// verificando todos os itens da lista e imprimindo na tela para o usuario
		}
	}
	public void totalConvertido() {			// funcao converter moeda
		double tcv=0;						// referencial para acumular o somatorio das convercoes das moedas armazenadas
		for(Moeda m: listaMoedas) {			// arco que verifica todos os itens da lista de moedas e acumula os seus valores convertidos
			tcv = tcv + m.converter();
		}
		System.out.println("Valor total convertido: "+tcv);
	}
}

package empresa;

public class Euro extends Moeda {   // classe filha da classe Moeda

	public Euro(double valor) {
		super(valor);
	}

	@Override
	void info() {
		System.out.println("Valor em euros no cofrinho: "+valor);
	}

	@Override
	double converter() {			// metodo converter especifico para conversao de euro em real
		return valor * 5.38;
	}

	@Override
	public String toString() {		// metodo para determinar como retornar os valores armazenados na classe
		return "Euro  [valor = " + valor + "]";
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}	
}
